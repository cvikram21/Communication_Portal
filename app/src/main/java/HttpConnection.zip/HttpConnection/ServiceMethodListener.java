package HttpConnection;


public interface ServiceMethodListener {
	public void getResponse(String data, String classname, String methodname);
}